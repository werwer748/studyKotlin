package com.bokchi.mysampleapp

data class Model (
    val title : String =""
)